function require_role($allowed_roles) {
    if (!in_array($_SESSION['role'], (array)$allowed_roles)) {
        http_response_code(403);
        exit('Access Denied');
    }
}

#session hijacking prevention
session_set_cookie_params([
  'secure' => true,
  'httponly' => true,
  'samesite' => 'Strict'
]);

#to be placed in auth.php at the top
<?php
session_start();

// Set session timeout duration (in seconds)
$timeout_duration = 900; // 15 minutes

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit;
}

$_SESSION['last_activity'] = time(); // Update last activity timestamp


#in login.php for session timeouts

<?php if (isset($_GET['timeout'])): ?>
    <p class="error">Session expired. Please log in again.</p>
<?php endif;?>
    
# in auth.php
if (DEMO_MODE) {
  $_SESSION['user_id'] = 1;
  $_SESSION['role'] = 'admin';
} else {
  // real auth checks
}


#on every page
<!-- Session Timeout Warning -->
<div id="session-warning" style="display:none; position:fixed; bottom:0; width:100%; background:#ffc107; color:#000; text-align:center; padding:15px; font-weight:bold; z-index:1000;">
    You will be logged out soon due to inactivity.
    <button onclick="stayLoggedIn()" style="margin-left:15px; background:#343a40; color:white; border:none; padding:6px 12px; cursor:pointer; border-radius:5px;">Stay Logged In</button>
</div>

<script>
const timeout = 15 * 60 * 1000; // 15 minutes
const warningTime = 14 * 60 * 1000; // Show warning after 14 minutes

let timeoutWarning = setTimeout(() => {
    document.getElementById('session-warning').style.display = 'block';
}, warningTime);

let autoLogout = setTimeout(() => {
    window.location.href = 'logout.php?timeout=1';
}, timeout);

function stayLoggedIn() {
    fetch('ping.php'); // reset the session
    clearTimeout(timeoutWarning);
    clearTimeout(autoLogout);
    document.getElementById('session-warning').style.display = 'none';
    
    // restart timers
    timeoutWarning = setTimeout(() => {
        document.getElementById('session-warning').style.display = 'block';
    }, warningTime);
    autoLogout = setTimeout(() => {
        window.location.href = 'logout.php?timeout=1';
    }, timeout);
}

// Optional: reset timers on any user activity
['click', 'mousemove', 'keydown'].forEach(event => {
    document.addEventListener(event, () => {
        stayLoggedIn();
    });
});
</script>



#near tge top of the login form
<?php if (isset($_GET['timeout'])): ?>
    <p class="error">You were logged out due to inactivity.</p>
<?php endif; ?>