
INSERT INTO users (name, email, password, role)
VALUES ('Admin User', 'admin@example.com', '$2y$10$eW5Q2QMRsmUu7f0/J6zVuulGv7wCdgu0YAGUvL4X7/cUGV5EF7BLu', 'admin');
-- Password: admin123
