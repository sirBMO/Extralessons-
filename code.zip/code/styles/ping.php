<?php
session_start();
// Silently refresh session timer
http_response_code(204);