<?php
include 'db.php';
session_start();

// Get and sanitize input
$name = htmlspecialchars(trim($_POST['name']));
$email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
$password = trim($_POST['password']);

if ($name && $email && $password) {
  if (strlen($password) < 6) {
    echo "Password must be at least 6 characters.";
    exit();
  }

  // Check if email already exists
  $checkStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
  $checkStmt->bind_param("s", $email);
  $checkStmt->execute();
  $checkStmt->store_result();

  if ($checkStmt->num_rows > 0) {
    echo "Email already registered.";
    exit();
  }
  $checkStmt->close();

  // Hash password and insert user
  $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
  $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
  $stmt->bind_param("sss", $name, $email, $hashedPassword);

  if ($stmt->execute()) {
    $_SESSION['parent_id'] = $stmt->insert_id;
    header("Location: index.html");
    exit();
  } else {
    echo "Registration error: " . $stmt->error;
  }
} else {
  echo "Please fill in all fields correctly.";
}
?>