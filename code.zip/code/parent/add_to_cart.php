<?php
session_start();
include("db.php");

$package_id = intval($_GET['id']);

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (!in_array($package_id, $_SESSION['cart'])) {
    $_SESSION['cart'][] = $package_id;
}

header("Location: cart.php");
exit;