<?php
session_start();
include 'auth.php';
require_role(['parent']);
include 'db.php';

$visiblePackages = $conn->query("SELECT * FROM packages WHERE visible = 1");

#include("db.php");

$query = "SELECT * FROM packages WHERE status = 'Active'";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Packages | Extra Lessons</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fc; font-family: 'Nunito', sans-serif; }
        .package-card {
            border: none;
            border-radius: 0.5rem;
            box-shadow: 0 0.15rem 1.5rem rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .package-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0.5rem 1.5rem rgba(0,0,0,0.15);
        }
    </style>
</head>
<body>


<div class="container my-5">
    <h3 class="mb-4">Available Packages</h3>
    <div class="row">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($pkg = $result->fetch_assoc()): ?>
                <div class="col-md-4 mb-4">
                    <div class="card package-card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($pkg['title']) ?></h5>
                            <p class="card-text text-muted"><?= htmlspecialchars($pkg['description']) ?></p>
                            <p><strong>Grade Level:</strong> <?= ucfirst($pkg['category']) ?></p>
                            <p><strong>Price:</strong> R<?= number_format($pkg['price'], 2) ?></p>
                            <a href="add_to_cart.php?id=<?= $pkg['id'] ?>" class="btn btn-sm btn-success">Add to Cart</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="text-muted">No packages available at the moment.</p>
        <?php endif; ?>
    </div>
</div>

<div class="content-wrapper">
  <h2>Available Packages</h2>
  <div class="card-grid">
    <?php while ($p = $visiblePackages->fetch_assoc()): ?>
    <div class="dashboard-card">
      <h4><?= htmlspecialchars($p['name']) ?></h4>
      <p><?= nl2br(htmlspecialchars($p['description'])) ?></p>
      <p><strong>R<?= number_format($p['price'], 2) ?></strong></p>
      <form method="POST" action="add_to_cart.php">
        <input type="hidden" name="package_id" value="<?= $p['id'] ?>">
        <button type="submit" class="btn">Add to Cart</button>
      </form>
    </div>
    <?php endwhile; ?>
  </div>
</div>

</body>
</html>