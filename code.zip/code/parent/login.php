<?php
// login.php – Handles user login

include 'db.php';
session_start();

// Get and sanitize input
$email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
$password = trim($_POST['password']);

// Validate input
if ($email && $password) {
  // Fetch user by email
  $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ?");
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $stmt->store_result();

  if ($stmt->num_rows === 1) {
    $stmt->bind_result($userId, $hashedPassword);
    $stmt->fetch();

    // Verify password
    if (password_verify($password, $hashedPassword)) {
      $_SESSION['parent_id'] = $userId;
      header("Location: dashboard.php");
      exit();
    } else {
      echo "Incorrect email or password.";
    }
  } else {
    echo "Incorrect email or password.";
  }
  $stmt->close();
} else {
  echo "Please fill in all fields.";
}
?>