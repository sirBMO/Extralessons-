<?php
session_start();
include("auth.php");
include("db.php");

$parent_id = $_SESSION['user_id'];
$child_id = $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM children WHERE id = ? AND parent_id = ?");
$stmt->bind_param("ii", $child_id, $parent_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Child not found or access denied.");
}
$child = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>View Child | Extra Lessons</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h3>Child Details</h3>
    <div class="card p-4 shadow-sm mt-3">
        <p><strong>Name:</strong> <?= htmlspecialchars($child['name']) ?></p>
        <p><strong>Grade:</strong> <?= htmlspecialchars($child['grade']) ?></p>
        <p><strong>Status:</strong> <?= $child['status'] ?></p>
        <a href="my_children.php" class="btn btn-secondary">Back</a>
    </div>
</div>
</body>
</html>