<?php
// Handle child enrollment form submission
session_start();
include ("auth.php");
include 'db.php'; // Database connection

// Ensure user is logged in
if (!isset($_SESSION['parent_id'])) {
  header("Location: login.php");
  exit();
}

// Get parent ID from session
$parent_id = $_SESSION['parent_id'];

// Get and sanitize form input
$name = trim($_POST['name']);
$grade = trim($_POST['grade']);
$level = trim($_POST['level']);

if ($name && $grade && $level) {
  // Insert child info into the database
  $stmt = $conn->prepare("INSERT INTO children (parent_id, name, grade, level) VALUES (?, ?, ?, ?)");
  $stmt->bind_param("isss", $parent_id, $name, $grade, $level);
  if ($stmt->execute()) {
    echo "Child enrolled successfully.";
  } else {
    echo "Error: " . $stmt->error;
  }
} else {
  echo "Please complete all fields.";
}

$conn->close();
?>