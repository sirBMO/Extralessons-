<?php
session_start();
include("db.php");

$cart = $_SESSION['cart'] ?? [];

$packages = [];
$total = 0;

if ($cart) {
    $placeholders = implode(',', array_fill(0, count($cart), '?'));
    $types = str_repeat('i', count($cart));
    $stmt = $conn->prepare("SELECT * FROM packages WHERE id IN ($placeholders)");
    $stmt->bind_param($types, ...$cart);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $packages[] = $row;
        $total += $row['price'];
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cart | Extra Lessons</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h3 class="mb-4">My Cart</h3>
    <?php if ($packages): ?>
        <table class="table table-bordered shadow-sm">
            <thead>
                <tr>
                    <th>Package</th>
                    <th>Category</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($packages as $pkg): ?>
                    <tr>
                        <td><?= htmlspecialchars($pkg['title']) ?></td>
                        <td><?= ucfirst($pkg['category']) ?></td>
                        <td>R<?= number_format($pkg['price'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="text-end">
            <h5>Total: <strong>R<?= number_format($total, 2) ?></strong></h5>
        </div>
        <div class="mt-3">
            <a href="packages.php" class="btn btn-secondary">Continue Browsing</a>
            <a href="checkout.php" class="btn btn-success">Proceed to Checkout</a>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">Your cart is empty.</div>
        <a href="packages.php" class="btn btn-primary">Browse Packages</a>
    <?php endif; ?>
</div>
</body>
</html>