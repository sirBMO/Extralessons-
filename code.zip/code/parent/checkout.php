<?php
session_start();
include("db.php");

$parent_id = $_SESSION['user_id'];
$cart = $_SESSION['cart'] ?? [];

if (empty($cart)) {
    header("Location: cart.php");
    exit;
}

$placeholders = implode(',', array_fill(0, count($cart), '?'));
$types = str_repeat('i', count($cart));
$stmt = $conn->prepare("SELECT * FROM packages WHERE id IN ($placeholders)");
$stmt->bind_param($types, ...$cart);
$stmt->execute();
$result = $stmt->get_result();

$packages = [];
$total = 0;
while ($row = $result->fetch_assoc()) {
    $packages[] = $row;
    $total += $row['price'];
}

// Insert order
$order_stmt = $conn->prepare("INSERT INTO orders (parent_id, total) VALUES (?, ?)");
$order_stmt->bind_param("id", $parent_id, $total);
$order_stmt->execute();
$order_id = $conn->insert_id;

// Insert order items
$item_stmt = $conn->prepare("INSERT INTO order_items (order_id, package_id, price) VALUES (?, ?, ?)");
foreach ($packages as $pkg) {
    $item_stmt->bind_param("iid", $order_id, $pkg['id'], $pkg['price']);
    $item_stmt->execute();
}

$_SESSION['cart'] = []; // Clear cart

// Redirect to invoice
header("Location: invoice.php?order_id=" . $order_id);
exit;