<?php
session_start();
include("db.php");

$parent_id = $_SESSION['user_id']; // Assumes user_id is stored in session after login

// Fetch children
$stmt = $conn->prepare("SELECT * FROM children WHERE parent_id = ?");
$stmt->bind_param("i", $parent_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Children | Extra Lessons</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fc; font-family: 'Nunito', sans-serif; }
        .card { box-shadow: 0 0.15rem 1.75rem rgba(58,59,69,.15); }
    </style>
</head>
<body>

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>My Children</h3>
        <a href="dashboard.html" class="btn btn-primary">Add Child</a>
    </div>

    <div class="card">
        <div class="card-body">
            <?php if ($result->num_rows > 0): ?>
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Name</th>
                            <th>Grade</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($child = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($child['name']) ?></td>
                                <td><?= htmlspecialchars($child['grade']) ?></td>
                                <td>
                                    <span class="badge bg-<?= $child['status'] == 'Active' ? 'success' : 'secondary' ?>">
                                        <?= $child['status'] ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="view_child.php?id=<?= $child['id'] ?>" class="btn btn-sm btn-outline-primary">View</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-muted">No children added yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>