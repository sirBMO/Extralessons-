<?php
include 'auth.php';
require_role(['parent']);
include 'db.php';

$parent_id = $_SESSION['user_id'];
$q = "
  SELECT c.name AS child, p.name AS package, e.status
  FROM enrollments e
  JOIN children c ON e.child_id = c.id
  JOIN packages p ON e.package_id = p.id
  WHERE c.parent_id = $parent_id
";
$enrollments = $conn->query($q);
?>
<div class="content-wrapper">
  <h2>My Enrollments</h2>
  <table>
    <thead><tr><th>Child</th><th>Package</th><th>Status</th></tr></thead>
    <tbody>
      <?php while($e = $enrollments->fetch_assoc()): ?>
      <tr>
        <td><?= $e['child'] ?></td>
        <td><?= $e['package'] ?></td>
        <td><span class="badge bg-<?= strtolower($e['status']) ?>"><?= $e['status'] ?></span></td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>