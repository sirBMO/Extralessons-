<?php
// parent_dashboard.php
session_start();
include("db.php");   // Database connection

// Example values for dashboard (replace with DB queries)
$activeChildren = 2;
$currentEnrollments = 3;
$completedPackages = 5;
$pendingPayments = 1;

// Optional: get current page for nav highlighting
$page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parent Dashboard | Extra Lessons</title>
    
    <link href="style1.css" rel="stylesheet">
    
</head>
<body>

<div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar-wrapper">
        <div class="sidebar-heading text-center py-4">
            <h3 class="text-white">Extra Lessons</h3>
        </div>
        <div class="list-group list-group-flush">
            <a href="parent_dashboard.php" class="nav-link <?= $page == 'dashboard.php' ? 'active' : '' ?>">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            
            <a href="my_children.php" class="nav-link <?= $page == 'my_children.php' ? 'active' : '' ?>">
                <i class="fas fa-child"></i> My Children
            </a>
            <a href="packages.php" class="nav-link <?= $page == 'packages.php' ? 'active' : '' ?>">
                <i class="fas fa-book"></i> Packages
            </a>
            <a href="cart.php" class="nav-link <?= $page == 'cart.php' ? 'active' : '' ?>">
                <i class="fas fa-shopping-cart"></i> Cart
            </a>
            <a href="enrollments.php" class="nav-link <?= $page == 'enrollments.php' ? 'active' : '' ?>">
                <i class="fas fa-calendar-check"></i> Enrollments
            </a>
            <a href="add_child.php" class="nav-link <?= $page == 'add_child.php' ? 'active' : '' ?>">
                <i class="fas fa-credit-card"></i> Register child
            </a>
            <a href="settings.php" class="nav-link <?= $page == 'settings.php' ? 'active' : '' ?>">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a href="logout.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <!-- Page Content -->
    <div id="page-content-wrapper">
        <!-- Top Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white topbar px-4">
            <button class="btn btn-outline-secondary me-2" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            <h4 class="text-gray-800 my-2">Dashboard</h4>

            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown no-arrow mx-2">
                    <a class="nav-link dropdown-toggle" href="#">
                        <i class="fas fa-bell fa-fw"></i>
                        <span class="badge bg-danger rounded-pill">3+</span>
                    </a>
                </li>
                <li class="nav-item dropdown no-arrow mx-2">
                    <a class="nav-link dropdown-toggle" href="#">
                        <i class="fas fa-envelope fa-fw"></i>
                        <span class="badge bg-danger rounded-pill">2</span>
                    </a>
                </li>
                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#">
                        <span class="d-none d-lg-inline text-gray-600 small">Parent User</span>
                        <img class="img-profile rounded-circle" src="https://source.unsplash.com/QAB-WJcbgJk/60x60" alt="Profile">
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Dashboard Content -->
        <div class="container-fluid px-4">
            <div class="row mb-4">
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card stat-card h-100 py-2">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-xs fw-bold text-primary text-uppercase mb-1">Active Children</div>
                                    <div class="h5 mb-0 fw-bold text-gray-800"><?= $activeChildren ?></div>
                                </div>
                                <i class="fas fa-child fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card stat-card h-100 py-2">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-xs fw-bold text-primary text-uppercase mb-1">Current Enrollments</div>
                                    <div class="h5 mb-0 fw-bold text-gray-800"><?= $currentEnrollments ?></div>
                                </div>
                                <i class="fas fa-calendar-check fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card stat-card success h-100 py-2">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-xs fw-bold text-success text-uppercase mb-1">Completed Packages</div>
                                    <div class="h5 mb-0 fw-bold text-gray-800"><?= $completedPackages ?></div>
                                </div>
                                <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card stat-card h-100 py-2">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-xs fw-bold text-primary text-uppercase mb-1">Pending Payments</div>
                                    <div class="h5 mb-0 fw-bold text-gray-800"><?= $pendingPayments ?></div>
                                </div>
                                <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Add more dashboard sections here -->
        </div>
    </div>
</div>

<script>
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.sidebar');

    toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('toggled');
    });
</script>
<script>
    document.getElementById('sidebarToggle').addEventListener('click', function () {
        document.getElementById('wrapper').classList.toggle('toggled');
    });
</script>

</body>
</html>