<?php
session_start();

$timeout_duration = 900; // 15 minutes

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit;
}

$_SESSION['last_activity'] = time(); // Update last activity timestamp

// Ensure the user is logged in
define('DEMO_MODE', true);

if (DEMO_MODE) {
  $_SESSION['user_id'] = 8;
  $_SESSION['role'] = 'admin';
} else {
  // real auth checks




    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }

}
// Optional helper to restrict access by role
function require_role($allowed_roles) {
    if (!in_array($_SESSION['role'], (array) $allowed_roles)) {
        http_response_code(403);
        echo "<h2>403 - Access Denied</h2><p>You do not have permission to view this page.</p>";
        exit;
    }
}
