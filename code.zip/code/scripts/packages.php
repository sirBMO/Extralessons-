<?php
include 'auth.php';
require_role(['parent']);
include 'db.php';

$visiblePackages = $conn->query("SELECT * FROM packages WHERE visible = 1");
?>
<div class="content-wrapper">
  <h2>Available Packages</h2>
  <div class="card-grid">
    <?php while ($p = $visiblePackages->fetch_assoc()): ?>
    <div class="dashboard-card">
      <h4><?= htmlspecialchars($p['name']) ?></h4>
      <p><?= nl2br(htmlspecialchars($p['description'])) ?></p>
      <p><strong>R<?= number_format($p['price'], 2) ?></strong></p>
      <form method="POST" action="add_to_cart.php">
        <input type="hidden" name="package_id" value="<?= $p['id'] ?>">
        <button type="submit" class="btn">Add to Cart</button>
      </form>
    </div>
    <?php endwhile; ?>
  </div>
</div>