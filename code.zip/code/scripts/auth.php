<?php
session_start();

// Redirect to login page if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Example user info in session (after login):
// $_SESSION['user_id'] = 1;
// $_SESSION['role'] = 'parent'; // or 'admin'

// Function to restrict access by role(s)
function require_role($roles = []) {
    if (!in_array($_SESSION['role'], (array)$roles)) {
        // Unauthorized access
        http_response_code(403);
        echo "Access denied.";
        exit;
    }
}

// Example usage:
// require_role(['admin']);   // Only admin can access
// require_role(['parent']);  // Only parents can access
// require_role(['admin', 'parent']); // Either role allowed