<?php
#session_start();
//include ('auth.php');
include ('db.php');
require_role(['admin','parent' ]);
// index.php
#$_SESSION['user_id'] = $user['id'];
//$_SESSION['role'] = $user['role']; // 'admin' or 'parent'
//$_SESSION['name'] = $user['name'];



/*if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } elseif ($_SESSION['role'] === 'parent') {
        header("Location: parent/dashboard.php");
    }
    exit;
}*/


?><!DOCTYPE html><html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome | LMS</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(to right, #004aad, #ffd700);
            color: #fff;
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .portal-container {
            background-color: white;
            color: #004aad;
            text-align: center;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            width: 90%;
            max-width: 500px;
        }
        .portal-container h2 {
            margin-bottom: 1rem;
            color: #004aad;
        }
        .portal-container p {
            margin-bottom: 1.5rem;
        }
        .portal-container button {
            margin: 0.5rem;
            padding: 0.75rem 2rem;
            font-size: 1rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            background-color: #004aad;
            color: white;
            transition: background-color 0.3s ease;
        }
        .portal-container button:hover {
            background-color: #003380;
        }
        @media (max-width: 600px) {
            .portal-container {
                padding: 1rem;
            }
            .portal-container button {
                width: 100%;
                margin-top: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="portal-container">
        <h2>Welcome to the LMS</h2>
        <p>Please choose your portal:</p>
        <a href="styles/login.html"><button>Parent Portal</button></a>
        <a href="styles/login.html"><button>Admin Portal</button></a>
    </div>
</body>
</html>