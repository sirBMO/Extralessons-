<?php
session_start();
include 'auth.php';
require_role(['admin']);
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $desc = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $visible = isset($_POST['visible']) ? 1 : 0;

    $stmt = $conn->prepare("INSERT INTO packages (name, description, price, visible) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssdi", $name, $desc, $price, $visible);
    $stmt->execute();
    header("Location: admin_packages.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="styles.css"></head>
<body>
<?php include 'admin_header.php'; ?>
<div class="content-wrapper">
  <h2>Add Package</h2>
  <form method="POST" class="form-box">
    <label>Name</label>
    <input type="text" name="name" required>
    
    <label>Description</label>
    <textarea name="description" rows="4" required></textarea>

    <label>Price (R)</label>
    <input type="number" name="price" step="0.01" required>

    <label><input type="checkbox" name="visible" checked> Show to Parents</label>

    <button type="submit" class="btn">Add Package</button>
  </form>
</div>

<!-- Session Timeout Warning -->
<div id="session-warning" style="display:none; position:fixed; bottom:0; width:100%; background:#ffc107; color:#000; text-align:center; padding:15px; font-weight:bold; z-index:1000;">
    You will be logged out soon due to inactivity.
    <button onclick="stayLoggedIn()" style="margin-left:15px; background:#343a40; color:white; border:none; padding:6px 12px; cursor:pointer; border-radius:5px;">Stay Logged In</button>
</div>

<script>
const timeout = 15 * 60 * 1000; // 15 minutes
const warningTime = 14 * 60 * 1000; // Show warning after 14 minutes

let timeoutWarning = setTimeout(() => {
    document.getElementById('session-warning').style.display = 'block';
}, warningTime);

let autoLogout = setTimeout(() => {
    window.location.href = 'logout.php?timeout=1';
}, timeout);

function stayLoggedIn() {
    fetch('ping.php'); // reset the session
    clearTimeout(timeoutWarning);
    clearTimeout(autoLogout);
    document.getElementById('session-warning').style.display = 'none';
    
    // restart timers
    timeoutWarning = setTimeout(() => {
        document.getElementById('session-warning').style.display = 'block';
    }, warningTime);
    autoLogout = setTimeout(() => {
        window.location.href = 'logout.php?timeout=1';
    }, timeout);
}

// Optional: reset timers on any user activity
['click', 'mousemove', 'keydown'].forEach(event => {
    document.addEventListener(event, () => {
        stayLoggedIn();
    });
});
</script>



</body>
</html>