<?php
// login.php – Handles user login
include 'auth.php';
include 'db.php';
require_role(['admin','parent' ]);
session_start();

$_SESSION['user_id'] = $user['id'];
$_SESSION['role'] = $user['role']; // 'admin' or 'parent'
$_SESSION['name'] = $user['name'];

// Get and sanitize input
$email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
$password = trim($_POST['password']);

if ($role !== 'admin') {
  header("Location: admin_dashboard.php");
  exit();
}
// Validate input
if ($email && $password) {
  // Fetch user by email
  $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ?");
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $stmt->store_result();

  if ($stmt->num_rows === 1) {
    $stmt->bind_result($userId, $hashedPassword);
    $stmt->fetch();

    // Verify password
    if (password_verify($password, $hashedPassword)) {
      $_SESSION['parent_id'] = $userId;
      header("Location: admin_dashboard.php");
      exit();
    } else {
      echo "Incorrect email or password.";
    }
  } else {
    echo "Incorrect email or password.";
  }
  $stmt->close();
} else {
  echo "Please fill in all fields.";
}
?>