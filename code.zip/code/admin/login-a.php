$_SESSION['user_id'] = $user['id'];
$_SESSION['role'] = $user['role']; // 'admin' or 'parent'
$_SESSION['name'] = $user['name'];