<?php
include("auth.php");
include("db.php");
require_role(['admin']);

if ($_SESSION['role'] !== 'admin') die("Access denied.");

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="orders.csv"');

$output = fopen("php://output", "w");
fputcsv($output, ['Order ID', 'Parent ID', 'Total', 'Status', 'Created At']);

$res = $conn->query("SELECT * FROM orders");
while ($row = $res->fetch_assoc()) {
    fputcsv($output, $row);
}
fclose($output);
exit;