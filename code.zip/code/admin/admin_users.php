<?php
session_start();
include("auth.php");
include("db.php");
require_role(['admin']);

if ($_SESSION['role'] !== 'admin') {
    die("Access denied.");
}

$users = $conn->query("SELECT id, name, email, created_at FROM users WHERE role = 'parent'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Users | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'admin_header.php'; ?>
<div class="container mt-5">
    <h3>Registered Parents</h3>
    <table class="table table-hover mt-3 shadow-sm">
        <thead class="table-light">
            <tr>
                <th>ID</th><th>Name</th><th>Email</th><th>Registered</th><th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($u = $users->fetch_assoc()): ?>
            <tr>
                <td><?= $u['id'] ?></td>
                <td><?= htmlspecialchars($u['name']) ?></td>
                <td><?= htmlspecialchars($u['email']) ?></td>
                <td><?= $u['created_at'] ?></td>
                <td>
                    <a href="admin_view_user.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-primary">View</a>
                    <a href="admin_delete_user.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?');">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Session Timeout Warning -->
<div id="session-warning" style="display:none; position:fixed; bottom:0; width:100%; background:#ffc107; color:#000; text-align:center; padding:15px; font-weight:bold; z-index:1000;">
    You will be logged out soon due to inactivity.
    <button onclick="stayLoggedIn()" style="margin-left:15px; background:#343a40; color:white; border:none; padding:6px 12px; cursor:pointer; border-radius:5px;">Stay Logged In</button>
</div>

<script>
const timeout = 15 * 60 * 1000; // 15 minutes
const warningTime = 14 * 60 * 1000; // Show warning after 14 minutes

let timeoutWarning = setTimeout(() => {
    document.getElementById('session-warning').style.display = 'block';
}, warningTime);

let autoLogout = setTimeout(() => {
    window.location.href = 'logout.php?timeout=1';
}, timeout);

function stayLoggedIn() {
    fetch('ping.php'); // reset the session
    clearTimeout(timeoutWarning);
    clearTimeout(autoLogout);
    document.getElementById('session-warning').style.display = 'none';
    
    // restart timers
    timeoutWarning = setTimeout(() => {
        document.getElementById('session-warning').style.display = 'block';
    }, warningTime);
    autoLogout = setTimeout(() => {
        window.location.href = 'logout.php?timeout=1';
    }, timeout);
}

// Optional: reset timers on any user activity
['click', 'mousemove', 'keydown'].forEach(event => {
    document.addEventListener(event, () => {
        stayLoggedIn();
    });
});
</script>
</body>
</html>