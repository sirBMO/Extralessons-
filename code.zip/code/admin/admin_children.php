<?php
session_start();
include 'auth.php';
require_role(['admin']);
include 'db.php';

$children = $conn->query("SELECT c.*, u.name AS parent FROM children c JOIN users u ON c.parent_id = u.id");
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="styles.css"></head>
<body>
<?php include 'admin_header.php'; ?>
<div class="content-wrapper">
  <h2>Children</h2>
  <table>
    <thead><tr><th>Name</th><th>Grade</th><th>Parent</th><th>Action</th></tr></thead>
    <tbody>
      <?php while ($c = $children->fetch_assoc()): ?>
      <tr>
        <td><?= $c['name'] ?></td>
        <td><?= $c['grade'] ?></td>
        <td><?= $c['parent'] ?></td>
        <td>
          <a href="delete_child.php?id=<?= $c['id'] ?>" class="btn btn-danger" onclick="return confirm('Delete child?')">Delete</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- Session Timeout Warning -->
<div id="session-warning" style="display:none; position:fixed; bottom:0; width:100%; background:#ffc107; color:#000; text-align:center; padding:15px; font-weight:bold; z-index:1000;">
    You will be logged out soon due to inactivity.
    <button onclick="stayLoggedIn()" style="margin-left:15px; background:#343a40; color:white; border:none; padding:6px 12px; cursor:pointer; border-radius:5px;">Stay Logged In</button>
</div>

<script>
const timeout = 15 * 60 * 1000; // 15 minutes
const warningTime = 14 * 60 * 1000; // Show warning after 14 minutes

let timeoutWarning = setTimeout(() => {
    document.getElementById('session-warning').style.display = 'block';
}, warningTime);

let autoLogout = setTimeout(() => {
    window.location.href = 'logout.php?timeout=1';
}, timeout);

function stayLoggedIn() {
    fetch('ping.php'); // reset the session
    clearTimeout(timeoutWarning);
    clearTimeout(autoLogout);
    document.getElementById('session-warning').style.display = 'none';
    
    // restart timers
    timeoutWarning = setTimeout(() => {
        document.getElementById('session-warning').style.display = 'block';
    }, warningTime);
    autoLogout = setTimeout(() => {
        window.location.href = 'logout.php?timeout=1';
    }, timeout);
}

// Optional: reset timers on any user activity
['click', 'mousemove', 'keydown'].forEach(event => {
    document.addEventListener(event, () => {
        stayLoggedIn();
    });
});
</script>

</body>
</html>