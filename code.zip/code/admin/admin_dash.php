<?php
session_start();
//include("auth.php");
include("db.php");
//require_role(['admin']);

/*$_SESSION['user_id'] = $user['id'];
$_SESSION['role'] = 
$user['role'];
if ($_SESSION['role'] !== 'admin') {
    die("Access denied.");
}*/

// Dashboard Metrics
$total_orders = $conn->query("SELECT COUNT(*) FROM orders")->fetch_row()[0];
$total_earnings = $conn->query("SELECT SUM(total) FROM orders WHERE status = 'Paid'")->fetch_row()[0] ?? 0;
$total_users = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'parent'")->fetch_row()[0];

// Weekly Orders Chart Data (last 6 weeks)
$chartData = [];
$result = $conn->query("
    SELECT 
        CONCAT('Week ', WEEK(order_date)) AS week_label,
        COUNT(*) AS total
    FROM orders
    WHERE order_date >= DATE_SUB(CURDATE(), INTERVAL 6 WEEK)
    GROUP BY WEEK(order_date), YEAR(order_date)
    ORDER BY YEAR(order_date), WEEK(order_date)
");

while ($row = $result->fetch_assoc()) {
    $chartData[] = $row;
}

$labels = array_column($chartData, 'week_label');
$values = array_column($chartData, 'total');

$js_labels = json_encode($labels);
$js_values = json_encode($values);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Dashboard</title>
  <style>
    :root {
      --primary: #003366;
      --accent: #FFD700;
      --background: #ffffff;
      --text: #111;
      --shadow: rgba(0, 0, 0, 0.1);
    }

    [data-theme='dark'] {
      --primary: #ffffff;
      --accent: #FFD700;
      --background: #121212;
      --text: #f0f0f0;
      --shadow: rgba(255, 255, 255, 0.05);
    }

    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: var(--background);
      color: var(--text);
      padding: 1rem;
      transition: background 0.3s, color 0.3s;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    .avatar {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .avatar img {
      width: 40px;
      height: 40px;
      border-radius: 50%;
    }

    .btn, .toggle-dark {
      padding: 0.4rem 1rem;
      background-color: var(--primary);
      color: var(--background);
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.9rem;
    }

    .toggle-dark {
      background: none;
      border: 1px solid var(--primary);
      color: var(--primary);
    }

    .row {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1.5rem;
    }

    .card {
      background-color: var(--background);
      border: 1px solid var(--primary);
      border-left: 5px solid var(--accent);
      border-radius: 12px;
      padding: 1.5rem;
      box-shadow: 0 4px 10px var(--shadow);
      transition: transform 0.2s ease;
    }

    .card:hover {
      transform: translateY(-4px);
    }

    .card-title {
      font-weight: bold;
      margin-bottom: 0.5rem;
      color: var(--primary);
    }

    .card-text {
      font-size: 2rem;
      color: var(--accent);
    }

    #chart {
      margin-top: 3rem;
      width: 100%;
      height: 300px;
    }

    @media (max-width: 600px) {
      .card-text {
        font-size: 1.5rem;
      }
    }
  </style>
</head>
<body data-theme="light">

<div class="container">
  <div class="header">
    <div class="avatar">
      <img src="https://ui-avatars.com/api/?name=Admin&background=003366&color=fff" alt="Admin Avatar">
      <div>
        <strong>Welcome, Admin</strong><br>
        <a href="logout.php" style="color: var(--accent); font-size: 0.85rem; text-decoration: none;">Logout</a>
      </div>
    </div>
    <button class="toggle-dark" onclick="toggleTheme()">🌙 Toggle Theme</button>
  </div>

  <div class="row">
    <div class="card">
      <div class="card-title">Total Orders</div>
      <div class="card-text" id="orders">0</div>
    </div>
    <div class="card">
      <div class="card-title">Total Earnings</div>
      <div class="card-text" id="earnings">R0.00</div>
    </div>
    <div class="card">
      <div class="card-title">Registered Parents</div>
      <div class="card-text" id="users">0</div>
    </div>
  </div>

  <canvas id="chart"></canvas>
</div>

<script>
  // Dashboard Stats
  const totals = {
    orders: <?= $total_orders ?>,
    earnings: <?= $total_earnings ?>,
    users: <?= $total_users ?>
  };

  function animateValue(id, start, end, prefix = '', suffix = '', duration = 1000) {
    let obj = document.getElementById(id);
    let range = end - start;
    let startTime = null;

    function step(timestamp) {
      if (!startTime) startTime = timestamp;
      let progress = Math.min((timestamp - startTime) / duration, 1);
      obj.textContent = prefix + Math.floor(progress * range + start) + suffix;
      if (progress < 1) requestAnimationFrame(step);
    }

    requestAnimationFrame(step);
  }

  animateValue("orders", 0, totals.orders);
  animateValue("earnings", 0, totals.earnings, 'R', '', 1200);
  animateValue("users", 0, totals.users);

  // Theme toggle
  function toggleTheme() {
    const body = document.body;
    const theme = body.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    body.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }

  const savedTheme = localStorage.getItem('theme');
  if (savedTheme) document.body.setAttribute('data-theme', savedTheme);

  // Chart Drawing
  const labels = <?= $js_labels ?>;
  const data = <?= $js_values ?>;
  const canvas = document.getElementById('chart');
  const ctx = canvas.getContext('2d');

  function drawBarChart(ctx, data, labels) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const max = Math.max(...data);
    const barWidth = 40;
    const gap = 20;
    const chartHeight = 250;

    data.forEach((val, i) => {
      let height = (val / max) * chartHeight;
      let x = i * (barWidth + gap) + 50;
      ctx.fillStyle = '#FFD700';
      ctx.fillRect(x, chartHeight - height + 30, barWidth, height);
      ctx.fillStyle = 'var(--text)';
      ctx.fillText(labels[i], x, chartHeight + 50);
      ctx.fillText(val, x + 10, chartHeight - height + 25);
    });
  }

  drawBarChart(ctx, data, labels);
</script>

<!-- Session Timeout Warning -->
<div id="session-warning" style="display:none; position:fixed; bottom:0; width:100%; background:#ffc107; color:#000; text-align:center; padding:15px; font-weight:bold; z-index:1000;">
    You will be logged out soon due to inactivity.
    <button onclick="stayLoggedIn()" style="margin-left:15px; background:#343a40; color:white; border:none; padding:6px 12px; cursor:pointer; border-radius:5px;">Stay Logged In</button>
</div>

<script>
const timeout = 15 * 60 * 1000; // 15 minutes
const warningTime = 14 * 60 * 1000; // Show warning after 14 minutes

let timeoutWarning = setTimeout(() => {
    document.getElementById('session-warning').style.display = 'block';
}, warningTime);

let autoLogout = setTimeout(() => {
    window.location.href = 'logout.php?timeout=1';
}, timeout);

function stayLoggedIn() {
    fetch('ping.php'); // reset the session
    clearTimeout(timeoutWarning);
    clearTimeout(autoLogout);
    document.getElementById('session-warning').style.display = 'none';
    
    // restart timers
    timeoutWarning = setTimeout(() => {
        document.getElementById('session-warning').style.display = 'block';
    }, warningTime);
    autoLogout = setTimeout(() => {
        window.location.href = 'logout.php?timeout=1';
    }, timeout);
}

// Optional: reset timers on any user activity
['click', 'mousemove', 'keydown'].forEach(event => {
    document.addEventListener(event, () => {
        stayLoggedIn();
    });
});
</script>


</body>
</html>