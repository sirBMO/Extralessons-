<?php
session_start();
session_unset();
session_destroy();
header("Location: ../styles/login.php");
exit();
?>