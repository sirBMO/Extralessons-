<?php
session_start();
//include("auth.php");
include("db.php");
/*require_role(['admin']);

// Verify admin role
if ($_SESSION['role'] !== 'admin') {
    die("Access denied.");
}*/

// Fetch orders with parent info
$query = "
    SELECT o.id AS order_id, u.name AS parent_name, o.total, o.created_at, o.status 
    FROM orders o
    JOIN users u ON o.parent_id = u.id
    ORDER BY o.created_at DESC
";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin | Orders</title>
    <link href="style1.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h3 class="mb-4">All Orders</h3>
    <table class="table table-bordered table-hover shadow-sm">
        <thead class="table-light">
            <tr>
                <th>Order ID</th>
                <th>Parent</th>
                <th>Total (ZAR)</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td>#<?= $row['order_id'] ?></td>
                <td><?= htmlspecialchars($row['parent_name']) ?></td>
                <td>R<?= number_format($row['total'], 2) ?></td>
                <td><?= $row['created_at'] ?></td>
                <td><span class="badge bg-<?= $row['status'] == 'Paid' ? 'success' : ($row['status'] == 'Cancelled' ? 'danger' : 'warning') ?>">
                    <?= $row['status'] ?>
                </span></td>
                <td>
                    <a href="admin_view_order.php?id=<?= $row['order_id'] ?>" class="btn btn-sm btn-primary">View</a>
                    <a href="admin_update_order.php?id=<?= $row['order_id'] ?>&status=Paid" class="btn btn-sm btn-success">Mark as Paid</a>
                    <a href="admin_update_order.php?id=<?= $row['order_id'] ?>&status=Cancelled" class="btn btn-sm btn-danger">Cancel</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
                    <a href="export_orders.php" class="btn btn-sm btn-outline-info mb-3">Export CSV</a>
</body>
</html>