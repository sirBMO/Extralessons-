<?php
include 'auth.php';
require_role(['admin']);
include 'db.php';

$id = intval($_GET['id']);
$conn->query("DELETE FROM packages WHERE id = $id");
header("Location: admin_packages.php");
exit;