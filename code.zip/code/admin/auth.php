<?php
session_start();
include("db.php");

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Optional helper to restrict access by role
function require_role($allowed_roles) {
    if (!in_array($_SESSION['role'], (array) $allowed_roles)) {
        http_response_code(403);
        echo "<h2>403 - Access Denied</h2><p>You do not have permission to view this page.</p>";
        exit;
    }
}