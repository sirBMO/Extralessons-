<?php
session_start();

// Session timeout: 30 minutes
$timeoutDuration = 1800;

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeoutDuration) {
  session_unset();
  session_destroy();
  header("Location: login.php?timeout=1");
  exit();
}
$_SESSION['LAST_ACTIVITY'] = time(); // Update last activity time

// Require user login
if (!isset($_SESSION['parent_id'])) {
  header("Location: login.php");
  exit();
}

// Optional: Check user role if needed (see below)
?>