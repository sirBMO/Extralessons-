<?php
session_start();
include("auth.php");
include("db.php");
require_role(['admin']);

if ($_SESSION['role'] !== 'admin') {
    die("Access denied.");
}

$order_id = $_GET['id'];

$order = $conn->query("SELECT * FROM orders WHERE id = $order_id")->fetch_assoc();
$items = $conn->query("
    SELECT p.title, oi.price 
    FROM order_items oi 
    JOIN packages p ON oi.package_id = p.id 
    WHERE oi.order_id = $order_id
");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Order #<?= $order_id ?> | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h3 class="mb-3">Order #<?= $order_id ?></h3>
    <p><strong>Total:</strong> R<?= number_format($order['total'], 2) ?></p>
    <p><strong>Status:</strong> <?= $order['status'] ?></p>
    <p><strong>Date:</strong> <?= $order['created_at'] ?></p>

    <table class="table table-bordered mt-4">
        <thead class="table-light">
            <tr>
                <th>Package</th>
                <th>Price (ZAR)</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($item = $items->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($item['title']) ?></td>
                <td>R<?= number_format($item['price'], 2) ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <a href="admin_orders.php" class="btn btn-secondary">Back to Orders</a>
</div>
</body>
</html>