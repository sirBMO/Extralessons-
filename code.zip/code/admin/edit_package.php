<?php
include 'auth.php';
require_role(['admin']);
include 'db.php';

$id = intval($_GET['id']);
$pkg = $conn->query("SELECT * FROM packages WHERE id = $id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $desc = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $visible = isset($_POST['visible']) ? 1 : 0;

    $stmt = $conn->prepare("UPDATE packages SET name=?, description=?, price=?, visible=? WHERE id=?");
    $stmt->bind_param("ssdii", $name, $desc, $price, $visible, $id);
    $stmt->execute();
    header("Location: admin_packages.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="styles.css"></head>
<body>
<?php include 'admin_header.php'; ?>
<div class="content-wrapper">
  <h2>Edit Package</h2>
  <form method="POST" class="form-box">
    <label>Name</label>
    <input type="text" name="name" value="<?= htmlspecialchars($pkg['name']) ?>" required>
    
    <label>Description</label>
    <textarea name="description" rows="4" required><?= htmlspecialchars($pkg['description']) ?></textarea>

    <label>Price (R)</label>
    <input type="number" name="price" step="0.01" value="<?= $pkg['price'] ?>" required>

    <label><input type="checkbox" name="visible" <?= $pkg['visible'] ? 'checked' : '' ?>> Show to Parents</label>

    <button type="submit" class="btn">Update</button>
  </form>
</div>
</body>
</html>