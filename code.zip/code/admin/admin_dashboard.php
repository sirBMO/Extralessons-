<?php
session_start();
//include ("auth.php");
include("db.php");
//require_role(['admin']);

/*if ($_SESSION['role'] === 'admin') {
    die("Access denied.");
}*/

// Fetch stats
$total_orders = $conn->query("SELECT COUNT(*) FROM orders")->fetch_row()[0];
$total_earnings = $conn->query("SELECT SUM(total) FROM orders WHERE status = 'Paid'")->fetch_row()[0] ?? 0;
$total_users = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'parent'")->fetch_row()[0];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin Dashboard</title>
  <link href="styles.css" rel="stylesheet">
</head>
<body>
<?php include 'admin_header.php'; ?>
<div class="container mt-5">
  <h2>Welcome, Admin</h2>
  <div class="row mt-4">
    <div class="col-md-4">
      <div class="card text-white bg-primary mb-3">
        <div class="card-body">
          <h5 class="card-title">Total Orders</h5>
          <p class="card-text fs-3"><?= $total_orders ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-white bg-success mb-3">
        <div class="card-body">
          <h5 class="card-title">Total Earnings</h5>
          <p class="card-text fs-3">R<?= number_format($total_earnings, 2) ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-white bg-dark mb-3">
        <div class="card-body">
          <h5 class="card-title">Registered Parents</h5>
          <p class="card-text fs-3"><?= $total_users ?></p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Session Timeout Warning -->
<div id="session-warning" style="display:none; position:fixed; bottom:0; width:100%; background:#ffc107; color:#000; text-align:center; padding:15px; font-weight:bold; z-index:1000;">
    You will be logged out soon due to inactivity.
    <button onclick="stayLoggedIn()" style="margin-left:15px; background:#343a40; color:white; border:none; padding:6px 12px; cursor:pointer; border-radius:5px;">Stay Logged In</button>
</div>

<script>
const timeout = 15 * 60 * 1000; // 15 minutes
const warningTime = 14 * 60 * 1000; // Show warning after 14 minutes

let timeoutWarning = setTimeout(() => {
    document.getElementById('session-warning').style.display = 'block';
}, warningTime);

let autoLogout = setTimeout(() => {
    window.location.href = 'logout.php?timeout=1';
}, timeout);

function stayLoggedIn() {
    fetch('ping.php'); // reset the session
    clearTimeout(timeoutWarning);
    clearTimeout(autoLogout);
    document.getElementById('session-warning').style.display = 'none';
    
    // restart timers
    timeoutWarning = setTimeout(() => {
        document.getElementById('session-warning').style.display = 'block';
    }, warningTime);
    autoLogout = setTimeout(() => {
        window.location.href = 'logout.php?timeout=1';
    }, timeout);
}

// Optional: reset timers on any user activity
['click', 'mousemove', 'keydown'].forEach(event => {
    document.addEventListener(event, () => {
        stayLoggedIn();
    });
});
</script>


</body>
</html>