<?php
session_start();
//include("auth.php");
include("db.php");
//require_role(['admin']);

/*if ($_SESSION['role'] !== 'admin') {
    die("Access denied.");
}*/

$order_id = intval($_GET['id']);
$new_status = $_GET['status'];

$valid = ['Paid', 'Cancelled'];
if (in_array($new_status, $valid)) {
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $order_id);
    $stmt->execute();
}

header("Location: admin_orders.php");
exit;