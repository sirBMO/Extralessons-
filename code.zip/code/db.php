<?php
// db.php – Database connection script

// Database configuration
$host = 'localhost';        // Hostname (usually 'localhost')
$user = 'root';             // MySQL username
$pass = '';                 // MySQL password (keep secure)
$dbname = 'lessons';  // Your database name

// Create connection using MySQLi
$conn = new mysqli($host, $user, $pass, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// If connected successfully, this file will silently continue
?>